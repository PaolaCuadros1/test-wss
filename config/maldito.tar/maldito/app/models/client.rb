class Client
  include Mongoid::Document
  field :type_identification, type: String
  field :number_identification, type: Integer
  field :first_name, type: String
  field :last_name, type: String
  field :birthdate, type: Date
  field :gender, type: String
end
